package src;

public class Produto {

    public final String nome;
    public final double preco;

    public Produto(String nome, double preco){
        this.nome = nome;
        this.preco = preco;
    }
}
